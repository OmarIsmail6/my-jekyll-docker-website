#!/usr/bin/bash

echo "This is an example script that will be executed in the HTML root upon publishing."
echo "HTML root content:" $(ls)