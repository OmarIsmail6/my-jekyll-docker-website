---
layout: hub
title: Example Hub Page
citekey: test # automatically add links, abstract and bibtex entry from a publication
description: An _example_ for how to use hub pages.
links: # specify links manually
  - url: https://www.google.com
    description: Additional link
  - url: https://www.google.com
    description: Additional link with custom icon
    icon: "fas fa-coffee"
---

## Custom Content

You can insert custom content on a hub page by putting it here.